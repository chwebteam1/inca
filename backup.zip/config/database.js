module.exports = {

	// the database url to connect
	url : 'mongodb://localhost:27017'
}
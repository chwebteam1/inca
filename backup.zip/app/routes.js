var Todo = require('./models/todo');
var hug = require('./models/hug');
module.exports = function(app) {

	// api ---------------------------------------------------------------------
	// get all todos
	app.get('/api/todos', function(req, res) {

		// use mongoose to get all todos in the database
		Todo.find(function(err, todos) {

			// if there is an error retrieving, send the error. nothing after res.send(err) will execute
			if (err)
				res.send(err)

			res.json(todos); // return all todos in JSON format
		});
	});

	// create todo and send back all todos after creation
	app.post('/api/todos', function(req, res) {

		// create a todo, information comes from AJAX request from Angular
		Todo.create({
			text : req.body.text,
			done : false
		}, function(err, todo) {
			if (err)
				res.send(err);

			// get and return all the todos after you create another
			Todo.find(function(err, todos) {
				if (err)
					res.send(err)
				res.json(todos);
			});
		});

	});

	// update todo and send back all todos after modification
	app.put('/api/todos/:todo_id', function(req, res) {

		// update a todo, information comes from AJAX request from Angular
		var id = req.params.todo_id;
		var contenu = req.body.text;
		console.log(req);
		var criteria = {_id: id};
		var doc = {text: contenu};
		//console.log(req);
		var cb = function(err, todo) {
			if (err) // error here why ?
				console.log(err); // not displaying error

			// get and return all the todos after you update
			Todo.find(function(err, todos) {
				if (err)
					res.send(err)
				//res.json(todos);
			});
		};
		Todo.update(criteria, doc, cb);

	});

	// delete a todo
	app.delete('/api/todos/:todo_id', function(req, res) {
		Todo.remove({
			_id : req.params.todo_id
		}, function(err, todo) {
			if (err)
				res.send(err);

			// get and return all the todos after you create another
			Todo.find(function(err, todos) {
				if (err)
					res.send(err)
				res.json(todos);
			});
		});
	});

	// application -------------------------------------------------------------
	app.get('*', function(req, res) {
		res.sendfile('./public/index.html'); // load the single view file (angular will handle the page changes on the front-end)
	});
};
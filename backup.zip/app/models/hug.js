var mongoose = require('mongoose');

module.exports = mongoose.model('hug', {
  UNIT_LIST: {
      properties: {
        UNIT: {
          properties: {
            ROOM: {
              items: {
                properties: {
                  BED: {
                    items: {
                      properties: {
                        PATIENT: {
                          properties: {
                            ACT_GROUP: {
                              properties: {
                                ACT: {
                                  properties: {
                                    INFO_PART_LIST: {
                                      properties: {
                                        INFO_PART: {
                                          items: {
                                            properties: {
                                              _: {
                                          //      default: "diurèse horaire"
                                              }
                                            }
                                          }
                                        }
                                      }
                                    },
                                    PLANNED_DATE: {
                                      properties: {
                                        _: {
                                      //    default: "3 août 2011"
                                        }
                                      }
                                    },
                                    INFORMATION: {
                                   //   default : "<b>Relevé liquidiens</b>  relevé hydrique et diurèse horaire"
                                    },
                                    INTERVENTION: {
                                      properties: {
                                        INTERVENTION: {
                                          properties: {
                                            INTERVENTION: {
                                              properties: {
                                                INTERVENTION: {
                                                  properties: {}
                                                }
                                              }
                                            }
                                          }
                                        }
                                      }
                                    }
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }

});